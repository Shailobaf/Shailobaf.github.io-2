const cards = [...document.querySelectorAll(".card-item")]
cards.map(card => {
    card.addEventListener("click", () => {
        cards.map(card => card.classList.remove("card-active"))
        card.classList.toggle("card-active")
    })
}) 


var splide = new Splide( '.splide', {
  type   : 'loop',
  perPage: 3,
  focus  : 'center',
} );

splide.mount();